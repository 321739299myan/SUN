class Friend{
  final id;
  final id_customer;
  final id_friend_customer;
  final status;
  Friend({this.id, this.id_customer,this.id_friend_customer,this.status});
}