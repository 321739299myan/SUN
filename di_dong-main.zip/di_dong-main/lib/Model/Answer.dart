class Answer{
  final id;
  final name_answer;
  final result;//bool
  final status;
  Answer({this.id, this.name_answer,this.result, this.status});
}