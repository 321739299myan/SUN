class QuestionDetail{
  final id;
  final name_question_detail;
  final status;
  QuestionDetail({this.id, this.name_question_detail,this.status});
}