class Question{
  final id;
  final id_question_detail;
  final title;
  final id_answer;
  final point;
  final status;
  Question({this.id, this.id_question_detail, this.title, this.id_answer, this.point, this.status});
}