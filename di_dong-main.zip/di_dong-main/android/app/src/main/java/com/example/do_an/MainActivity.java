package com.example.do_an;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
